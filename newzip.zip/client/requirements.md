## Packages
framer-motion | Animations for entrance effects and hover states
react-icons | Social media and tech stack icons (FaWhatsapp, FaTelegram, etc)
react-scroll | Smooth scrolling navigation between sections

## Notes
Tailwind Config: Add 'JetBrains Mono' to font-family
Theme: Dark mode default, Neon Blue (#00f3ff) accent
Images: Use Unsplash for cyber/tech backgrounds if needed, otherwise CSS gradients/grid patterns
