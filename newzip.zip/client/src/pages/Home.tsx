import { Navigation } from "@/components/Navigation";
import { ServiceCard } from "@/components/ServiceCard";
import { ProjectCard } from "@/components/ProjectCard";
import { SectionHeading } from "@/components/SectionHeading";
import { useProjects } from "@/hooks/use-projects";
import { useSendMessage } from "@/hooks/use-messages";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { insertMessageSchema } from "@shared/schema";
import { z } from "zod";
import { motion } from "framer-motion";
import { 
  ShieldCheck, 
  Network, 
  Terminal, 
  UserCheck, 
  Globe, 
  BookOpen,
  Send,
  Loader2,
  Mail,
  Linkedin,
  Github
} from "lucide-react";
import { FaWhatsapp, FaTelegram } from "react-icons/fa";

// Import scroll link for hero button
import { Link as ScrollLink } from "react-scroll";

const services = [
  {
    title: "Cyber Security Training",
    description: "Comprehensive training from basics to advanced ethical hacking concepts. Learn to defend and secure networks.",
    icon: ShieldCheck
  },
  {
    title: "CCNA Guidance",
    description: "Expert guidance for networking fundamentals, routing protocols, and switching concepts to crack CCNA.",
    icon: Network
  },
  {
    title: "Linux Mastery",
    description: "Beginner to Advanced Linux administration guides. Master the command line and server management.",
    icon: Terminal
  },
  {
    title: "1:1 Mentorship",
    description: "Personalized mentorship sessions to guide your career path in Cyber Security and Networking.",
    icon: UserCheck
  },
  {
    title: "Web Development",
    description: "Full-stack website building support with secure coding practices and modern technologies.",
    icon: Globe
  },
  {
    title: "Study Resources",
    description: "Access to curated collection of free study materials, cheat sheets, and practice labs.",
    icon: BookOpen
  }
];

export default function Home() {
  const { data: projects, isLoading: projectsLoading } = useProjects();
  const { mutate: sendMessage, isPending: isSending } = useSendMessage();
  const { toast } = useToast();

  const form = useForm<z.infer<typeof insertMessageSchema>>({
    resolver: zodResolver(insertMessageSchema),
    defaultValues: {
      name: "",
      email: "",
      message: ""
    }
  });

  const onSubmit = (data: z.infer<typeof insertMessageSchema>) => {
    sendMessage(data, {
      onSuccess: () => {
        toast({
          title: "Message Sent!",
          description: "I will get back to you as soon as possible.",
          className: "bg-primary text-black border-none"
        });
        form.reset();
      },
      onError: (error) => {
        toast({
          title: "Error",
          description: error.message,
          variant: "destructive"
        });
      }
    });
  };

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden font-sans">
      <Navigation />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-16 cyber-grid">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/50 to-background pointer-events-none" />
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="mb-8 relative inline-block"
          >
            <div className="absolute -inset-1 bg-gradient-to-r from-primary to-accent rounded-full blur opacity-30 animate-pulse" />
            {/* Placeholder for Profile Image - Cyber Avatar style */}
            <div className="relative w-40 h-40 mx-auto rounded-full bg-black border-2 border-primary flex items-center justify-center overflow-hidden">
               <ShieldCheck className="w-20 h-20 text-primary animate-pulse" />
            </div>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-4xl md:text-7xl font-bold mb-6 font-mono tracking-tighter"
          >
            DEBOJIT SINGH
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-xl md:text-2xl text-primary/80 mb-8 font-mono"
          >
            Cyber Security & Networking Mentor
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <ScrollLink to="contact" smooth={true} duration={500}>
              <Button size="lg" className="bg-primary text-black hover:bg-primary/90 font-bold px-8 text-lg h-14">
                Start Learning
              </Button>
            </ScrollLink>
            <ScrollLink to="projects" smooth={true} duration={500}>
              <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary/10 font-bold px-8 text-lg h-14">
                View Projects
              </Button>
            </ScrollLink>
          </motion.div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 bg-black relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading title="MY SERVICES" subtitle="Everything you need to master tech" />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <ServiceCard key={index} {...service} delay={index * 0.1} />
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-secondary/20 relative border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-4xl font-bold font-mono mb-6 text-primary">
                &lt;About_Me /&gt;
              </h2>
              <div className="space-y-6 text-lg text-muted-foreground">
                <p>
                  Hello! I'm <span className="text-white font-bold">Debojit Singh</span>, a passionate cybersecurity enthusiast and networking specialist. My journey began with a curiosity about how the internet works, which evolved into a deep dive into network infrastructure and security protocols.
                </p>
                <p>
                  With extensive experience in <span className="text-primary">CCNA, Linux Administration, and Ethical Hacking</span>, I dedicate my time to mentoring the next generation of security professionals.
                </p>
                <p>
                  I believe that knowledge should be accessible to everyone. That's why I provide free resources and guidance to help you navigate the complex landscape of cybersecurity.
                </p>
              </div>
              
              <div className="mt-8 flex gap-4">
                <a href="https://linkedin.com" target="_blank" rel="noreferrer" className="p-3 rounded-full bg-secondary hover:bg-primary hover:text-black transition-colors">
                  <Linkedin className="w-6 h-6" />
                </a>
                <a href="https://github.com" target="_blank" rel="noreferrer" className="p-3 rounded-full bg-secondary hover:bg-primary hover:text-black transition-colors">
                  <Github className="w-6 h-6" />
                </a>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="absolute -inset-4 bg-primary/20 rounded-xl blur-xl" />
              <div className="relative bg-black border border-primary/30 p-8 rounded-xl font-mono text-sm leading-relaxed">
                <div className="flex gap-2 mb-4">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                </div>
                <p className="text-green-400">$ whoami</p>
                <p className="text-white mb-4">Debojit Singh</p>
                
                <p className="text-green-400">$ cat skills.txt</p>
                <p className="text-white mb-4">
                  [<br/>
                  &nbsp;&nbsp;"Network Security",<br/>
                  &nbsp;&nbsp;"Penetration Testing",<br/>
                  &nbsp;&nbsp;"Linux Administration",<br/>
                  &nbsp;&nbsp;"Cisco Routing & Switching",<br/>
                  &nbsp;&nbsp;"Web Development"<br/>
                  ]
                </p>

                <p className="text-green-400">$ echo "Let's Connect!"</p>
                <p className="text-white animate-pulse">_</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-24 bg-black relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading title="LATEST PROJECTS" subtitle="Labs, Configs & Code" />

          {projectsLoading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="w-12 h-12 text-primary animate-spin" />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {projects?.length === 0 ? (
                // Fallback content if no projects in DB yet
                <>
                  <ProjectCard 
                    title="Network Topology Lab"
                    description="Complex enterprise network simulation using GNS3 with OSPF multi-area configuration."
                    imageUrl="https://images.unsplash.com/photo-1544197150-b99a580bbcbf?auto=format&fit=crop&q=80&w=800"
                    projectUrl="#"
                    tags={["GNS3", "OSPF", "Cisco"]}
                    delay={0}
                  />
                  <ProjectCard 
                    title="Linux Hardening Script"
                    description="Automated bash script for hardening Ubuntu servers against common vulnerabilities."
                    imageUrl="https://images.unsplash.com/photo-1629654297299-c8506221ca97?auto=format&fit=crop&q=80&w=800"
                    projectUrl="#"
                    tags={["Bash", "Linux", "Security"]}
                    delay={0.1}
                  />
                  <ProjectCard 
                    title="Python Port Scanner"
                    description="Multi-threaded port scanner built with Python socket library for network reconnaissance."
                    imageUrl="https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&q=80&w=800"
                    projectUrl="#"
                    tags={["Python", "Networking", "Tools"]}
                    delay={0.2}
                  />
                </>
              ) : (
                projects?.map((project, index) => (
                  <ProjectCard 
                    key={project.id}
                    title={project.title}
                    description={project.description}
                    imageUrl={project.imageUrl}
                    projectUrl={project.projectUrl}
                    tags={project.tags}
                    delay={index * 0.1}
                  />
                ))
              )}
            </div>
          )}
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-secondary/10 border-t border-white/5 relative overflow-hidden">
        {/* Decorative background elements */}
        <div className="absolute top-0 right-0 w-1/2 h-full bg-primary/5 -skew-x-12 transform translate-x-1/4" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <SectionHeading title="GET IN TOUCH" subtitle="Start your journey today" />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div className="space-y-8">
              <h3 className="text-2xl font-bold text-white mb-6">Connect Directly</h3>
              
              <a href="mailto:debojit@example.com" className="flex items-center gap-4 p-6 bg-secondary/50 rounded-xl border border-white/5 hover:border-primary/50 transition-all group">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary group-hover:text-black transition-colors">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-white">Email Me</h4>
                  <p className="text-muted-foreground group-hover:text-primary transition-colors">debojit@example.com</p>
                </div>
              </a>

              <a href="https://wa.me/1234567890" target="_blank" rel="noreferrer" className="flex items-center gap-4 p-6 bg-secondary/50 rounded-xl border border-white/5 hover:border-green-500/50 transition-all group">
                <div className="w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center group-hover:bg-green-500 group-hover:text-black transition-colors text-green-500">
                  <FaWhatsapp className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-white">WhatsApp</h4>
                  <p className="text-muted-foreground group-hover:text-green-500 transition-colors">Chat on WhatsApp</p>
                </div>
              </a>

              <a href="https://t.me/debojitsec" target="_blank" rel="noreferrer" className="flex items-center gap-4 p-6 bg-secondary/50 rounded-xl border border-white/5 hover:border-blue-500/50 transition-all group">
                <div className="w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center group-hover:bg-blue-500 group-hover:text-black transition-colors text-blue-500">
                  <FaTelegram className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-white">Telegram Channel</h4>
                  <p className="text-muted-foreground group-hover:text-blue-500 transition-colors">Join Community</p>
                </div>
              </a>
            </div>

            {/* Contact Form */}
            <div className="bg-secondary/30 p-8 rounded-2xl border border-white/10">
              <h3 className="text-2xl font-bold text-white mb-6">Send a Message</h3>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Name</label>
                  <Input 
                    {...form.register("name")}
                    placeholder="John Doe" 
                    className="bg-black/50 border-white/10 focus:border-primary/50 text-white placeholder:text-gray-600 h-12"
                  />
                  {form.formState.errors.name && (
                    <p className="text-red-500 text-xs">{form.formState.errors.name.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Email</label>
                  <Input 
                    {...form.register("email")}
                    placeholder="john@example.com" 
                    type="email"
                    className="bg-black/50 border-white/10 focus:border-primary/50 text-white placeholder:text-gray-600 h-12"
                  />
                  {form.formState.errors.email && (
                    <p className="text-red-500 text-xs">{form.formState.errors.email.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Message</label>
                  <Textarea 
                    {...form.register("message")}
                    placeholder="How can I help you?" 
                    className="bg-black/50 border-white/10 focus:border-primary/50 text-white placeholder:text-gray-600 min-h-[150px]"
                  />
                  {form.formState.errors.message && (
                    <p className="text-red-500 text-xs">{form.formState.errors.message.message}</p>
                  )}
                </div>

                <Button 
                  type="submit" 
                  disabled={isSending}
                  className="w-full bg-primary text-black hover:bg-primary/90 font-bold h-12 text-lg"
                >
                  {isSending ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Sending...
                    </>
                  ) : (
                    <>
                      Send Message <Send className="ml-2 h-5 w-5" />
                    </>
                  )}
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black border-t border-white/10 py-12 text-center">
        <p className="text-muted-foreground font-mono">
          &copy; {new Date().getFullYear()} Debojit Singh. All rights reserved.
        </p>
        <p className="text-xs text-muted-foreground/50 mt-2">
          Secure. Connect. Evolve.
        </p>
      </footer>
    </div>
  );
}
