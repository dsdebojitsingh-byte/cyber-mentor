import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Projects API
  app.get(api.projects.list.path, async (req, res) => {
    const projects = await storage.getProjects();
    res.json(projects);
  });

  app.post(api.projects.create.path, async (req, res) => {
    try {
      const input = api.projects.create.input.parse(req.body);
      const project = await storage.createProject(input);
      res.status(201).json(project);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Messages API
  app.post(api.messages.create.path, async (req, res) => {
    try {
      const input = api.messages.create.input.parse(req.body);
      const message = await storage.createMessage(input);
      res.status(201).json(message);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Initial Seed Data (if empty)
  const existingProjects = await storage.getProjects();
  if (existingProjects.length === 0) {
    await storage.createProject({
      title: "Secure Network Architecture",
      description: "Designed and implemented a secure 3-tier network architecture for a medium-sized enterprise, incorporating VLANs, DMZ, and redundant firewalls.",
      imageUrl: "https://images.unsplash.com/photo-1558494949-efc0257bb3af?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      tags: ["Networking", "Security", "Architecture"],
      projectUrl: "#"
    });
    
    await storage.createProject({
      title: "ACL Configuration & Filtering",
      description: "Implemented complex Access Control Lists (ACLs) on Cisco routers to filter traffic based on security policies, mitigating potential internal threats.",
      imageUrl: "https://images.unsplash.com/photo-1544197150-b99a580bbc7c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      tags: ["Cisco", "ACL", "Security"],
      projectUrl: "#"
    });

    await storage.createProject({
      title: "OSPF & EIGRP Routing",
      description: "Configured and optimized OSPF and EIGRP routing protocols for dynamic routing across multiple sites, ensuring high availability and load balancing.",
      imageUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      tags: ["Routing", "OSPF", "EIGRP"],
      projectUrl: "#"
    });

    await storage.createProject({
      title: "Linux Server Hardening",
      description: "Comprehensive hardening of Linux servers (Ubuntu/CentOS) including SSH hardening, firewall configuration (UFW/iptables), and regular auditing.",
      imageUrl: "https://images.unsplash.com/photo-1629654297299-c8506221ca97?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      tags: ["Linux", "Hardening", "Security"],
      projectUrl: "#"
    });
  }

  return httpServer;
}
